# Auteur
Rémy POTTIEZ & Théo METEYER 

# Introduction

Ceci contient le code de la web application pour le "projet esport" pour le projet INFO_04 Architecture des Systèmes d'Information à rendre le 20/06/2021.

# Environnement

	## Logiciels utilisés:
		- Visual Studio 2019

	## Langages utilisés:
		- C# 
		- HTML
		- CSS

	## Type:
		- Web application
		- ASP .Net Core
		- .Net 5

	## BDD: 
		- SQL Server localdb ((localdb)\MSSQLLocalDB)

# Identiants compte admin
 	- email : admin@projetEsport.com
	- mdp : I@m@dmin1234

# Explications
	L'administrateur à accès au BackOffice via l'url: /Admin, aussi accessbile depuis le menu de gestion du compte de l'utilisateur: /Identity/Account/Manage
	avec le bouton admin.

	La demande de licence comme évoqué dans l'énoncer est éffectuer par la création d'un compte utilisateur
	Une fois le compte créer l'administrateur doit approuver l'utilisateur depuis le BackOffice: /Admin/Users/ApproveUsers